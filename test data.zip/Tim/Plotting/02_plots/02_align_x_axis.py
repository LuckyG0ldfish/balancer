from glob import glob
from pandas import read_csv
from pandas.core.frame import DataFrame

INPUT_DIR = "../01_measurements/unzipped"
PROCEDURES = ["reg"]
ADDITIONAL_COMMENT = ""
BASE_NF = "gnb"
BASE_NF_INSTANCES = 2
OFFSET = 10


def crappySlice(df: DataFrame, start: int = 0):
    while True:
        start = df[(df.index > start) & (df[BASE_NF] > 0)].first_valid_index()
        if start is not None:
            break
        else:
            return (start, None)
    end = start
    while True:
        end = df[(df.index > end) & (df[BASE_NF] == 0)].first_valid_index()
        return (start, end)


def requestsSlice(df: DataFrame, start: int=0):
    while True:
        start = df[(df.index > start) & (df["nrf-np"] > 10)].first_valid_index()
        if start is not None:
            break
        else:
            return (start, None)
    end = start
    while True:
        end = df[(df.index > end) & (df["nrf-np"] == 0)].first_valid_index()
        return (start, end)


for directory in glob(f"{INPUT_DIR}/*", recursive=False):
    print(f"{directory}")
    dfCpu = read_csv(directory + "/milli_cpu.csv", index_col="seconds")
    dfInstances = read_csv(directory + "/instances.csv", index_col="seconds")
    dfRequests = read_csv(directory + "/requests.csv", index_col="seconds")

    initial_start = 0
    start = 0
    end = 0
    for procedure in PROCEDURES:
        # Extract registration
        start, end = crappySlice(dfInstances, initial_start + 10)
        if start is not None:
            dfCpu[start - OFFSET: end + OFFSET].to_csv(
                directory + f"/{procedure}_milli_cpu.csv", index=True
            )
            dfInstances[start - OFFSET: end + OFFSET].to_csv(
                directory + f"/{procedure}_instances.csv", index=True
            )
            print(f"x-Axis for {procedure} has been aligned!")
        else:
            print(f"Did not detect {procedure} procedure being emulated!")

        start_reqs, end_reqs = requestsSlice(dfRequests, initial_start)
        if start_reqs is not None:
            dfRequests[start_reqs: end_reqs].to_csv(
                directory + f"/{procedure}_requests.csv", index=True
            )
            print(f"Requests values for {procedure} has been aligned!")
        else:
            print(f"Problem with Requests: Did not detect {procedure} procedure being emulated!")


        initial_start = end


