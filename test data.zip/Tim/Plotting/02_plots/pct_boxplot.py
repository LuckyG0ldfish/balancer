import logging
import os

import pandas as pd
from matplotlib.ticker import MaxNLocator
from pandas import DataFrame, read_csv
import matplotlib.pyplot as plt
import numpy as np
from glob import glob

logging.basicConfig(level=logging.INFO)
# logging.basicConfig(level=logging.DEBUG)

INPUT_DIR = "../01_measurements/unzipped"
PARENT_OUTPUT_DIR = "../03_output/"
PROCEDURES = ["reg", "dereg"]
PROCEDURE_NAMES_FOR_PLOTS = {"reg": "Registration",
                             "dereg": "Dere"}
ADDITIONAL_COMMENT = ""
OFFSET = 10
# NUMBER_OF_GNB = 10
INITIAL_GNB_ID = 1
BOXPLOTS = ["merged", "separate"]

DIRECTORIES = ["2022-03-27_200104", "2022-03-27_202109", "2022-03-27_202902", "2022-03-27_203614", "2022-03-27_210303"]

log = logging.getLogger(name="PCT")

log.info("Started the run.")

# For each of the saved measurements/scenarios
DIRECTORIES = ["{0}/{1}".format(INPUT_DIR, dir) for dir in DIRECTORIES]

for directory in glob(f"{INPUT_DIR}/*", recursive=False):
    print(DIRECTORIES)
    if directory in DIRECTORIES:
        log.debug(f"Directory name: {directory}")
        for procedure in PROCEDURES:

            try:
                pctDataFrame = read_csv(f"{directory}/pct-{procedure}.csv", index_col="ue_id")
            except FileNotFoundError:
                log.warning(f"File \"{directory}/pct-{procedure}.csv\" does not exists.")
                break

            if np.mean(pctDataFrame[f"gnb-{INITIAL_GNB_ID}"][:10]) == 0:
                log.warning(f"File {directory}/pct-{procedure}.csv is all-0. Skipping to next file.\n")
                break
            else:
                log.debug(pctDataFrame)

            # dfToPlot = DataFrame()

            fig, axes = plt.subplots(
                nrows=len(BOXPLOTS) + 1,
                ncols=1,
                figsize=(9, 3 + 2 * len(BOXPLOTS)),
            )
            axes = list(axes) if len(BOXPLOTS) > 1 else [axes]

            aggregateDataFrame = DataFrame()

            for boxplot_type in BOXPLOTS:
                if boxplot_type == "separate":
                    ax = axes.pop()

                    pctDataFrame.boxplot(
                        ax=ax,
                        showfliers=False,

                    )
                    ax.set_ylabel("PCT [ms]")
                    ax.yaxis.grid(True, alpha=0.5)

                    # ax.set_xlabel("gNB ID")

                    ax = axes.pop()
                    pctDataFrame.boxplot(
                        ax=ax,
                    )
                    ax.set_ylabel("PCT [ms]")
                    ax.yaxis.grid(True, alpha=0.5)


                elif boxplot_type == "merged":
                    ax = axes.pop()

                    numberOfGnbs = len(pctDataFrame.columns)
                    log.debug(f"Number of gNB detected from the DataFrame object:{numberOfGnbs}")

                    for gnbId in range(1, numberOfGnbs + 1):
                        aggregateDataFrame = pd.concat([aggregateDataFrame, pctDataFrame[f"gnb-{gnbId}"]],
                                                       ignore_index=True)

                    aggregateDataFrame.rename(columns={0: "All"}, inplace=True)

                    # log.info(f"Aggregated Data Frame: \n{aggregateDataFrame}")

                    aggregateDataFrame.boxplot(
                        ax=ax,
                        showfliers=False
                    )
                    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
                    ax.set_ylabel("PCT [ms]")
                    ax.set_xlabel("gNB ID")
                    ax.yaxis.grid(True, alpha=0.5)

                    log.info(f"[{PROCEDURE_NAMES_FOR_PLOTS[procedure]} - {directory}] -> mean={aggregateDataFrame.mean()}, median={aggregateDataFrame.median()}")

                    # plt.xticks([0], ['All'])
                    # ax.

            fig.suptitle(f"PCTs for {PROCEDURE_NAMES_FOR_PLOTS[procedure]} - {directory}")
            plt.show()
