import logging
import os

import pandas as pd
from matplotlib.ticker import MaxNLocator
from pandas import DataFrame, read_csv
import matplotlib.pyplot as plt
import numpy as np
from glob import glob

logging.basicConfig(level=logging.INFO)
# logging.basicConfig(level=logging.DEBUG)

INPUT_DIR = "../01_measurements/unzipped"
PARENT_OUTPUT_DIR = "../03_output/"
PROCEDURES = ["reg", "dereg"]
PROCEDURE_NAMES_FOR_PLOTS = {"reg": "Registration",
                             "dereg": "Dere"}
ADDITIONAL_COMMENT = ""
OFFSET = 10
INITIAL_GNB_ID = 1
GNBID_TO_PLOT = [1]
BOXPLOTS = ["separate"]

log = logging.getLogger(name="PCT")

log.info("Started the run.")

# For each of the saved measurements/scenarios
for directory in glob(f"{INPUT_DIR}/*", recursive=False):
    log.debug(f"Directory name: {directory}")
    scenario = directory.replace(f"{INPUT_DIR}/", "")
    for procedure in PROCEDURES:

        try:
            pctDataFrame = read_csv(f"{directory}/pct-{procedure}.csv", index_col="ue_id")
        except FileNotFoundError:
            log.warning(f"File \"{directory}/pct-{procedure}.csv\" does not exists.")
            break

        if np.mean(pctDataFrame[f"gnb-{INITIAL_GNB_ID}"][:10]) == 0:
            log.warning(f"File {directory}/pct-{procedure}.csv is all-0. Skipping to next file.")
            break
        else:
            log.debug(pctDataFrame)

        numberOfGnbs = len(GNBID_TO_PLOT)

        fig, axes = plt.subplots(
            nrows=len(GNBID_TO_PLOT),
            ncols=1,
            figsize=(9, 3 + 3 * len(BOXPLOTS)),
        )
        axes = list(axes) if len(GNBID_TO_PLOT) > 1 else [axes]

        for boxplot_type in BOXPLOTS:
            if boxplot_type == "separate":
                for gnbId in GNBID_TO_PLOT:
                    ax = axes.pop()

                    try:
                        columnToCopy = pctDataFrame.loc[:, [f"gnb-{gnbId}"]]
                        # columnToCopy = pctDataFrame.pop(f"gnb-{gnbId}")
                        dfToPlot = columnToCopy.copy()
                        # dfToPlot.set_index("ue_id", inplace=True)

                        # dfToPlot.rename(columns={"pct": f"gnb-{gnbId}"}, inplace=True)
                        # log.info(dfToPlot.columns())
                        log.info(f"{dfToPlot}")

                        # dfToPlot.drop(dfToPlot.loc[dfToPlot[f"gnb-{gnbId}"] == 0].index, inplace=True)

                        dfToPlot.plot(
                            ax=ax,
                            linestyle='None',
                            marker='o',
                            markersize=1,
                        )
                        ax.set_ylabel("PCT [ms]")
                        # ax.set_ylim(0, 400)
                        ax.yaxis.grid(True, alpha=0.5)
                    except KeyError:
                        log.warning(f"Key [gnb-{gnbId}] not found.")


        fig.suptitle(f"Line plot PCTs for {PROCEDURE_NAMES_FOR_PLOTS[procedure]} - {scenario}")

        output_dir = PARENT_OUTPUT_DIR + f"{scenario}/"
        try:
            # Create target Directory
            os.mkdir(output_dir)
            print("Directory \"", output_dir, "\" created.")
        except FileExistsError:
            print("Directory \"", output_dir, "\" already exists.")

        plt.savefig(output_dir + "pct_lineplot.png")

        plt.show()
