# Extract zip files from 18_evaluation/dump.py from the export/ directory there and pivot cpu and instances tables
import os
import shutil

from pandas import DataFrame, read_csv, merge
from zipfile import ZIP_BZIP2, ZipFile
from io import BytesIO
import matplotlib.pyplot as plt
from glob import glob

NUMBER_OF_GNB = 10
INPUT_DIR = "../01_measurements/input"
PARENT_OUTPUT_DIR = "../01_measurements/unzipped/"
# PROCEDURES = ["reg", "dereg"]
PROCEDURES = ["reg"]
ADDITIONAL_COMMENT = "Scaler is not deployed. Resources are not constrained."

for file in glob(f"{INPUT_DIR}/*.zip"):
    df = None
    print(file)

    input_filename = file.split("/")[-1]

    # Create output directory where the extracted data will be written.
    if "-trace-dump.zip" in input_filename:
        output_dir = PARENT_OUTPUT_DIR + input_filename.replace("-trace-dump.zip", "/")
        print(output_dir)

    elif "dump-" in input_filename:
        output_dir = PARENT_OUTPUT_DIR + input_filename.replace("dump-", "")
        output_dir = output_dir.replace(".zip", "/")
        print(output_dir)
    try:
        # Create target Directory
        os.mkdir(output_dir)
        print("Directory \"", output_dir, "\" created.")
    except FileExistsError:
        print("Directory \"", output_dir, "\" already exists.")

    with ZipFile(file, mode="r", compression=ZIP_BZIP2) as archive:
        comment = archive.read("comment.txt").decode("utf-8")
        print(comment)

        # Extract all archive in a temp directory (will be deleted later):
        temp_directory = output_dir + "temp/"
        archive.extractall(path=temp_directory)

        # Save comment to output directory and append text if desired
        archive.extract("comment.txt", path=output_dir)
        if ADDITIONAL_COMMENT != "":
            output_comment = open(output_dir + "comment.txt", "a")
            output_comment.write("Additional comment about the measurement: " + ADDITIONAL_COMMENT)
            output_comment.close()

        # Extract CPU values
        df = read_csv(BytesIO(archive.read("rs_cpu_utilization.csv")))
        # Given in percent -> to milli CPU
        df["value"] = df["value"] * 10

        df = df.pivot_table(
            index=["timestamp"],
            columns="function",
            values="value",
            aggfunc="sum",
            fill_value=0.0,
        )
        df = df.reset_index(drop=True)
        df.index.name = "seconds"
        df.to_csv(output_dir + "milli_cpu.csv")

        # --------------------------

        # Extract instance count
        df = read_csv(BytesIO(archive.read("rs_instance_count.csv")))
        df = df.pivot_table(
            index=["timestamp"],
            columns="function",
            values="value",
            aggfunc="sum",
            fill_value=0,
        )
        df = df.reset_index(drop=True)
        df.index.name = "seconds"
        df.to_csv(output_dir + "instances.csv")

        # Extract number of requests

        df = read_csv(BytesIO(archive.read("istio_requests_2s.csv")))
        df = df.pivot_table(
            index=["timestamp"],
            columns="destination_service_name",
            values="value",
            aggfunc="sum",
            fill_value=0,
        )
        df = df.reset_index(drop=True)
        df.index.name = "seconds"
        df.to_csv(output_dir + "requests.csv")

        # Extract PCTs for all gNBs
        for procedure in PROCEDURES:
            aggregate_df = None
            for gnb_id in range(1, NUMBER_OF_GNB + 1):
                # print("for gnb_id in range(1, NUMBER_OF_GNB + 1)")

                for pct_file in glob(temp_directory + f"*-{procedure}-{gnb_id}.csv"):
                    # print("for pct_file in glob(temp_directory ")

                    print(pct_file)

                    df = read_csv(pct_file)
                    df.set_index("ue_id", inplace=True)
                    # print(dfCpu)

                    df.rename(columns={"pct": f"gnb-{gnb_id}"}, inplace=True)
                    df.drop(columns="gnb", inplace=True)
                    df.drop(df.loc[df[f"gnb-{gnb_id}"] < 0].index, inplace=True)
                    # print(dfCpu)

                    if gnb_id == 1:
                        aggregate_df = df
                    else:
                        aggregate_df = merge(aggregate_df, df, on="ue_id", how="left")

            # print(aggregate_df)
            aggregate_df.to_csv(output_dir + f"pct-{procedure}.csv")

    # Delete the Temp directory where the files were extracted.
    cleanup = True
    if cleanup:
        shutil.rmtree(temp_directory)

    # Rename file so that it is not extracted again.
    os.rename(file, file + ".bak")
