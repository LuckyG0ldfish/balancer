import time

import requests

old_report = 0
while 1:
    res = requests.get("http://10.244.0.111:29518/namf-oam/v1/ue-in-registration-report")
    print(res)
    print("UEs per second: ", int(res.text)-old_report)
    old_report = int(res.text)
    time.sleep(1)
