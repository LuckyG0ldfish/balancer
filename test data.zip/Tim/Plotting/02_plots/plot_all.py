import os

from pandas import read_csv, DataFrame
import matplotlib.pyplot as plt
import matplotlib
from matplotlib.ticker import MaxNLocator
import numpy as np

params = {"backend": "ps", "text.usetex": True, "font.family": "serif"}
#matplotlib.rcParams.update(params)

PARENT_OUTPUT_DIR = "../03_output/"


METRICS = [
    # filename, y-Label, smooth boolean
    # ("milli_cpu", "Ratios", False),
    ("instances", "Instances", False),
    ("milli_cpu", "CPU Utilization [mCPU]", False),
]

PLOTS = {
    # "plot-1": (  # plotName
    #     ["no-scale"],  # scenarios
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-2": (  # plotName
    #     ["hpa-fast-500m-100"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-3": (  # plotName
    #     ["hpa-fast-500m-90"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-4": (  # plotName
    #     ["hpa-fast-500m-80"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-5": (  # plotName
    #     ["hpa-fast-500m-80-2"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-6": (  # plotName
    #     ["hpa-def-500m-80"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-7": (  # plotName
    #     ["hpa-15s-500m-80"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-8": (  # plotName
    #     ["hpa-15s-500m-80-2"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-9": (  # plotName
    #     ["hpa-15s-500m-80-3"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-10": (  # plotName
    #     ["10"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-11": (  # plotName
    #     ["20"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-12": (  # plotName
    #     ["30"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-13": (  # plotName
    #     ["40"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-1": (  # plotName
    #     ["B-free5gc-100"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    "plot-1": (  # plotName
        ["no_resource_limit"],  # scenario
        {"registration": 1800, "deregistration": 250},  # times
        METRICS,
    ),
    # "plot-2": (  # plotName
    #     ["350m-HPA-80"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-3": (  # plotName
    #     ["350m-CPA-v1-15s"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
}
PROCEDURES = ["reg"]

FUNCTIONS = ["amf-stateless", "nrf", "udm-stateless", "pcf-stateless", "ausf-stateless"]
# FUNCTIONS = ["gnb", "nrf", "udm-stateless", "udr-stateless"]
# FUNCTIONS = ["registration", "udr", "nrf", "udsf"]
#FUNCTIONS = ["udm-stateless", "udr-stateless"]
# FUNCTIONS = ["amf", "udm", "udr", "nrf", "pcf", "ausf"]

RATIOS = ["nrf/amf", "udm/amf", "udr/amf"]
INPUT_DIR = "../01_measurements/unzipped"
ROLLING_AVERAGE = 10


for plot in PLOTS.items():
    plotName, value = plot
    scenarios, times, theseMetrics = value
    for procedure in PROCEDURES:
        fig, axes = plt.subplots(
            nrows=len(theseMetrics),
            ncols=1,
            # figsize=(9, 3 + 2*len(theseMetrics)),
            figsize=(10, 7),
            sharex=True,
        )
        plt.title(f"{scenarios[0]}")

        axes = list(axes) if len(theseMetrics) > 1 else [axes]
        for metric in theseMetrics:
            ax = axes.pop()
            styles = [
                (["#E09516", "#E09516", "#E09516"], ["-", "--"]),
                (["#8916E0", "#8916E0", "#8916E0"], ["-", "--"]),
                (["#00E059", "#00E059", "#00E059"], ["-", "--"]),
                (["#4885E0", "#4885E0", "#4885E0"], ["-", "--"]),
                (["#eb2828", "#eb2828", "#eb2828"], ["-", "--"]),
                (["#000000", "#000000", "#000000"], ["-", "--"]),
            ]
            zorder_array = [0, 10, 0]
            alpha = [1, 0.2]

            if metric[1] != "Ratios":
                for function in FUNCTIONS:
                    df = DataFrame()
                    print(plotName + "#" + function)
                    smooth = metric[2]

                    color, style = styles.pop()
                    index = 0
                    for scenario in scenarios:
                        df = DataFrame()

                        file = (
                            f"{INPUT_DIR}/{scenario}/{procedure}_{metric[0]}.csv"
                        )
                        m = read_csv(file)
                        print(file)
                        print(m.tail(1))

                        df[f"{function}"] = m[function]

                        df.plot(
                            ylabel=metric[1],
                            xlabel="Seconds",
                            ax=ax,
                            sharex=True,
                            x_compat=True,
                            style=style[index],
                            color=color[index],
                            legend=smooth,
                            zorder=zorder_array[index],
                            alpha=alpha[index]
                        )
                        index += 1

                    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
                    print(len(df))
                    ax.xaxis.set_ticks(np.arange(0, len(df), 45))
                    ax.xaxis.grid(True, alpha=0.5)
                    ax.yaxis.grid(True, alpha=0.5)

                    if metric[1] == "CPU Utilization [mCPU]":
                        ax.legend(
                            loc="lower center",
                            ncol=len(FUNCTIONS),
                            bbox_to_anchor=(0.5, 1.0)
                        )

                    ax.minorticks_off()
                    # ax.set_ylim(0, 1200)

            else:
                # This code is executed only when we want to plot the ratios in addition to the instances and cpu.
                for scenario in scenarios:
                    try:
                        df = read_csv(f"{INPUT_DIR}/{scenario}/{procedure}_{metric[0]}.csv")
                    except FileNotFoundError:
                        print(f"File \"{INPUT_DIR}/{scenario}/{procedure}_{metric[0]}.csv\" does not exists.")
                        break

                    df.rename(columns={"amf-stateless": "amf"}, inplace=True)
                    df.rename(columns={"udm-stateless": "udm"}, inplace=True)
                    df.rename(columns={"udr-stateless": "udr"}, inplace=True)

                    df = df.filter(items=['amf', 'nrf', 'udm', 'udr'])

                    # Prepare DataFrame for NRF/AMF ratio
                    df['nrf/amf'] = df['nrf'] / df['amf']
                    df['nrf/amf'].replace([np.inf, -np.inf], np.nan, inplace=True)
                    df['nrf/amf'] = df['nrf/amf'].fillna(0)
                    # df['nrf/amf'] = df['nrf/amf'].rolling(ROLLING_AVERAGE).mean()
                    df['nrf/amf'] = df['nrf/amf'][50:550].rolling(ROLLING_AVERAGE).mean()

                    # Prepare DataFrame for UDM/AMF ratio
                    df['udm/amf'] = df['udm'] / df['amf']
                    df['udm/amf'].replace([np.inf, -np.inf], np.nan, inplace=True)
                    df['udm/amf'] = df['udm/amf'].fillna(0)
                    # df['udm/amf'] = df['udm/amf'].rolling(ROLLING_AVERAGE).mean()
                    df['udm/amf'] = df['udm/amf'][50:550].rolling(ROLLING_AVERAGE).mean()

                    # Prepare DataFrame for UDR/AMF ratio
                    df['udr/amf'] = df['udr'] / df['amf']
                    df['udr/amf'].replace([np.inf, -np.inf], np.nan, inplace=True)
                    df['udr/amf'] = df['udr/amf'].fillna(0)
                    # df['udr/amf'] = df['udr/amf'].rolling(ROLLING_AVERAGE).mean()
                    df['udr/amf'] = df['udr/amf'][50:550].rolling(ROLLING_AVERAGE).mean()

                    df = df.filter(items=['nrf/amf', 'udm/amf', 'udr/amf'])

                    df.plot(
                        ylabel=metric[1],
                        xlabel="Seconds",
                        ax=ax,
                        sharex=True,
                        x_compat=True,
                        color={'nrf/amf': "#00E059", 'udm/amf': '#8916E0', 'udr/amf': '#E09516'},
                        alpha=1
                    )
                    ax.legend(
                        loc="lower center",
                        ncol=3,
                        bbox_to_anchor=(0.5, 1.0)
                    )
                # ax.yaxis.set_major_locator(MaxNLocator(integer=True))
                ax.xaxis.set_ticks(np.arange(0, len(df), 50))
                ax.xaxis.grid(True, alpha=0.5)
                ax.yaxis.grid(True, alpha=0.5)
                ax.minorticks_off()

        plt.tight_layout()
        plt.minorticks_off()
        # fig.suptitle(f"{scenarios[0]}")


        output_dir = PARENT_OUTPUT_DIR + f"{scenario}/"
        try:
            # Create target Directory
            os.mkdir(output_dir)
            print("Directory \"", output_dir, "\" created.")
        except FileExistsError:
            print("Directory \"", output_dir, "\" already exists.")

        if len(theseMetrics) == 2: #  meaning there are two metrics
            plt.savefig(output_dir + f"{theseMetrics[0][0]}_{theseMetrics[1][0]}_{procedure}.png")
        elif len(theseMetrics) == 3:
            plt.savefig(output_dir + f"all_metrics_{procedure}.png")
        plt.show()
