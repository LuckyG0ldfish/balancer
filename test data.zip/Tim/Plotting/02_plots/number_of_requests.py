import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import json
from glob import glob

from pandas import read_csv, DataFrame, concat
import pandas as pd

params = {"backend": "ps", "text.usetex": True, "font.family": "serif"}
matplotlib.rcParams.update(params)

# PROCEDURES = ["25", "50", "100", "200", "300"]
PROCEDURES = ["25", "50", "100", "200"]

WARMUP_CUTOFF_UES = 10

INPUT_DIR = "../01_measurements/unzipped"

CAMPAIGN = "A"

TITLE = f"{CAMPAIGN}-Missing-300"

def set_box_color(bp, color):
    plt.setp(bp['boxes'], color=color, linewidth=1.5)
    plt.setp(bp['whiskers'], color=color, linewidth=1.5)
    plt.setp(bp['caps'], color=color, linewidth=1.5)
    plt.setp(bp['medians'], color=color, linewidth=1.5)


def get_data(scenario, procedure):
    # candidate = glob(f"INPUT_DIR/{scenario}/pct-{procedure}.csv")

    # assert len(candidates) == 1

    df = read_csv(f"{INPUT_DIR}/{scenario}/{procedure}_requests.csv", index_col="seconds")
    # print(df)
    # df.drop(df.loc[df["ausf-np"] < 3].index, inplace=True)
    df["total"] = df.sum(axis=1)

    print(np.mean(df["total"]))
    return np.mean(df["total"])


for procedure in ["reg"]:
    print(f"Doing {procedure}")
    fig, axes = plt.subplots(figsize=(5, 6))

    free5gcDF = DataFrame()
    proceduresDF = DataFrame()

    free5g_25 = get_data(f"{CAMPAIGN}-free5gc-25", procedure)
    free5g_50 = get_data(f"B-free5gc-50", procedure)
    free5g_100 = get_data(f"B-free5gc-100", procedure)
    free5g_200 = get_data(f"{CAMPAIGN}-free5gc-200", procedure)
    # free5g_300 = get_data(f"{CAMPAIGN}-free5gc-200", procedure)

    procedure_25 = get_data(f"{CAMPAIGN}-procedures-25", procedure)
    procedure_50 = get_data(f"B-procedures-50", procedure)
    procedure_100 = get_data(f"B-procedures-100", procedure)
    procedure_200 = get_data(f"{CAMPAIGN}-procedures-200", procedure)
    # procedure_300 = get_data(f"{CAMPAIGN}-procedures-200", procedure)

    # procedure_udm_25 = get_data("K-procedures-udm-inline-25", procedure)
    # procedure_udm_50 = get_data("K-procedures-udm-inline-50", procedure)
    # procedure_udm_100 = get_data("K-procedures-udm-inline-100", procedure)
    # procedure_udm_200 = get_data("K-procedures-udm-inline-200", procedure)

    # procedure_wo_25 = get_data("A-all-stateless-25", procedure)
    # procedure_wo_50 = get_data("A-all-stateless-50", procedure)
    # procedure_wo_100 = get_data("A-all-stateless-100", procedure)
    # procedure_wo_200 = get_data("A-all-stateless-200", procedure)
    # procedure_wo_300 = get_data("A-all-stateless-200", procedure)


    collect = {
        "free5gc": free5gcDF,
        "procedures": proceduresDF,
    }

    for i in ['free5gc', 'procedures']:
        print(i)
        print(collect[i].median())

    flierprops = dict(marker='x', markersize=3)

    barplot1 = axes.bar(
        height=[free5g_25, free5g_50, free5g_100, free5g_200],
        x=np.arange(4) - 0.15,
        width=0.25,
        edgecolor='#fe9929',
        color='#fee391',
        linewidth=2,
        label="Free5GC-SBA"
    )
    barplot2 = axes.bar(
        height=[procedure_25, procedure_50, procedure_100, procedure_200],
        x=np.arange(4) + 0.15,
        width=0.25,
        edgecolor='#0E8088',
        color='#9AC7BF',
        linewidth=2,
        label="Free5GC-Procedural"
    )

    # barplot3 = axes.bar(
    #     height=[procedure_udm_25, procedure_udm_50, procedure_udm_100, procedure_udm_200],
    #     x=np.arange(4) + 0.3,
    #     width=0.25,
    #     edgecolor='black',
    #     color='gray',
    #     linewidth=2,
    #     label="Procedural"
    # )

    plt.legend(loc=2, fontsize=14)

    axes.set_xticks(range(4))
    axes.set_xticklabels(PROCEDURES)
    axes.grid(True, axis='y', linestyle="--", alpha=0.5)

    plt.xlabel("UEs per Second", fontsize=15)
    plt.ylabel("Avg. Number of HTTP Reqs/Sec", fontsize=15)

    axes.tick_params(axis='both', which='major', labelsize=13)
    # axes.tick_params(axis='both', which='minor', labelsize=8)

    # plt.ylim(top=620)
    plt.tight_layout()
    # plt.savefig(f"../03_output/{procedure}_requests.pdf", bbox_inches='tight', pad_inches=0.03)
    plt.savefig(f"/home/goshi/00_Nextcloud/02_NOKIA_UltraScalableCore/KuVS-paper/presentation/{procedure}_requests.png", bbox_inches='tight', pad_inches=0.03, dpi=300)
    # plt.title(f"{TITLE}")

    # istio.plot(y="mean-istio", yerr="stddev-istio", ax=ax)

# # beautify the x-labels   timestamps[:20],
# #plt.gcf().autofmt_xdate()
# plt.ylim(100, 500)
# plt.ylabel("Procedure Completion Times [ms]")
# plt.xlabel("UE ID")

# plt.tight_layout()

    plt.show()
