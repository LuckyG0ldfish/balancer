import os

from pandas import read_csv, DataFrame
import matplotlib.pyplot as plt
import matplotlib
from matplotlib.ticker import MaxNLocator
import numpy as np

params = {"backend": "ps", "text.usetex": True, "font.family": "serif"}
#matplotlib.rcParams.update(params)

PARENT_OUTPUT_DIR = "../03_output/"


METRICS = [
    ("instances", "Instances", False),
    ("milli_cpu", "CPU Utilization [mCPU]", False),
]

PLOTS = {
    "plot-1": (  # plotName
        ["2022-02-16_192538"],  # scenario
        {"registration": 1800, "deregistration": 250},  # times
        METRICS,
    ),
    "plot-2": (  # plotName
        ["2022-02-17_153423"],  # scenario
        {"registration": 1800, "deregistration": 250},  # times
        METRICS,
    ),
}
PROCEDURES = ["reg"]
FUNCTIONS = ["amf-stateless", "gnb", "mongod", "nrf", "udm-stateless", "udr-stateless"]
# MAX_X = 1300


for plot in PLOTS.items():
    plotName, value = plot
    scenarios, times, theseMetrics = value
    for procedure in PROCEDURES:
        fig, axes = plt.subplots(
            nrows=len(theseMetrics),
            ncols=1,
            figsize=(9, 3 + len(theseMetrics)),
            sharex=True,
        )
        axes = list(axes) if len(theseMetrics) > 1 else [axes]
        # max_x = times[procedure]
        for metric in theseMetrics:
            ax = axes.pop()
            styles = [
                (["#E09516", "#E09516", "#E09516"], ["-", "--"]),
                (["#8916E0", "#8916E0", "#8916E0"], ["-", "--"]),
                (["#00E059", "#00E059", "#00E059"], ["-", "--"]),
                (["#4885E0", "#4885E0", "#4885E0"], ["-", "--"]),
                (["#eb2828", "#eb2828", "#eb2828"], ["-", "--"]),
                (["#000000", "#000000", "#000000"], ["-", "--"]),
            ]
            zorder_array = [0, 10, 0]
            alpha = [1, 0.2]
            for function in FUNCTIONS:
                # if function == "amf" and metric[0] == "instances":
                #     continue  # do not plot instances for the AMF
                df = DataFrame()
                print(plotName + "#" + function)
                smooth = metric[2]

                color, style = styles.pop()
                index = 0
                for scenario in scenarios:
                    df = DataFrame()

                    file = (
                        f"../01_measurements/unzipped/{scenario}/{procedure}_{metric[0]}.csv"
                    )
                    m = read_csv(file)
                    print(file)
                    print(m.tail(1))
                    # dfCpu[f"{function}"] = (
                    #     m[function].rolling(7).mean() if smooth else m[function]
                    # )
                    df[f"{function}"] = m[function]

                    df.plot(
                        ylabel=metric[1],
                        xlabel="Seconds",
                        ax=ax,
                        sharex=True,
                        x_compat=True,
                        style=style[index],
                        color=color[index],
                        legend=smooth,
                        zorder=zorder_array[index],
                        alpha=alpha[index]
                    )
                    index += 1

                ax.yaxis.set_major_locator(MaxNLocator(integer=True))
                print(len(df))
                ax.xaxis.set_ticks(np.arange(0, len(df), 50))
                ax.xaxis.grid(True, alpha=0.5)

                if metric[0] == "instances":
                    # ax.set_ylim(bottom=1)
                    pass
                else:
                    # ax.set_ylim(bottom=0)
                    ax.legend(
                        # bbox_to_anchor=(1.5, 1),
                        loc="lower center",
                        # mode="expand",
                        # mode="lower center",
                        ncol=6,
                        # labelspacing=1,
                        bbox_to_anchor=(0.5, 1.0)
                    )
                    # ax.get_legend().set_bbox_to_anchor((0.5, 1))
                # ax.set_xlim(0, 800)
                ax.minorticks_off()
                #  plt.grid(True)
                # plt.legend(
                #     ,
                # )

        # plt.title = f"{plotName.replace('_', ' ')} {procedure}"
        plt.tight_layout()
        plt.minorticks_off()
        # plt.ylim(0, 1600)
        # plt.legend(loc="lower left", mode="expand", ncol=ceil(len(ax.lines) / 2))

        output_dir = PARENT_OUTPUT_DIR + f"{scenario}/"
        try:
            # Create target Directory
            os.mkdir(output_dir)
            print("Directory \"", output_dir, "\" created.")
        except FileExistsError:
            print("Directory \"", output_dir, "\" already exists.")

        if len(theseMetrics) > 1: #  meaning there are two metrics
            plt.savefig(output_dir + f"{theseMetrics[0][0]}_{theseMetrics[1][0]}_{procedure}.png")
        plt.show()
