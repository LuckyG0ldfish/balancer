import os
from pandas import DataFrame, read_csv
import matplotlib
# matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy as np

INPUT_DIR = "../01_measurements/unzipped/"
PARENT_OUTPUT_DIR = "../03_output/"
SCENARIOS = [
    "2022-02-16_192538", "2022-02-17_153423"
]
PROCEDURES = ["reg", "dereg"]
ADDITIONAL_COMMENT = ""
ROLLING_AVERAGE = 10


for scenario in SCENARIOS:
    for procedure in PROCEDURES:
        try:
            df = read_csv(INPUT_DIR + f"{scenario}/{procedure}_" + "milli_cpu.csv")

        except FileNotFoundError:
            print("File \"", INPUT_DIR + f"{scenario}/{procedure}_" + "milli_cpu.csv", "\" does not exists.")
            break

        df.rename(columns={"amf-stateless": "amf"}, inplace=True)
        df.rename(columns={"udm-stateless": "udm"}, inplace=True)
        df.rename(columns={"udr-stateless": "udr"}, inplace=True)

        df = df.filter(items=['amf', 'nrf', 'udm', 'udr'])

        # Prepare DataFrame for NRF/AMF ratio
        df['nrf/amf'] = df['nrf'] / df['amf']
        df['nrf/amf'].replace([np.inf, -np.inf], np.nan, inplace=True)
        df['nrf/amf'] = df['nrf/amf'].fillna(0)
        df['nrf/amf'] = df['nrf/amf'].rolling(ROLLING_AVERAGE).mean()

        # Prepare DataFrame for UDM/AMF ratio
        df['udm/amf'] = df['udm'] / df['amf']
        df['udm/amf'].replace([np.inf, -np.inf], np.nan, inplace=True)
        df['udm/amf'] = df['udm/amf'].fillna(0)
        df['udm/amf'] = df['udm/amf'].rolling(ROLLING_AVERAGE).mean()

        # Prepare DataFrame for UDR/AMF ratio
        df['udr/amf'] = df['udr'] / df['amf']
        df['udr/amf'].replace([np.inf, -np.inf], np.nan, inplace=True)
        df['udr/amf'] = df['udr/amf'].fillna(0)
        df['udr/amf'] = df['udr/amf'].rolling(ROLLING_AVERAGE).mean()

        df = df.filter(items=['nrf/amf', 'udm/amf', 'udr/amf'])
        df.plot(color={'nrf/amf': 'b', 'udm/amf': 'y', 'udr/amf': 'g'})

        output_dir = PARENT_OUTPUT_DIR + f"{scenario}/"
        try:
            # Create target Directory
            os.mkdir(output_dir)
            print("Directory \"", output_dir, "\" created.")
        except FileExistsError:
            print("Directory \"", output_dir, "\" already exists.")

        plt.savefig(output_dir + 'cpu_ratios.png')
        plt.show()

