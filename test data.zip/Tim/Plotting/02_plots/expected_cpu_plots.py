import os

from pandas import read_csv, DataFrame
import matplotlib.pyplot as plt
import matplotlib
from matplotlib.ticker import MaxNLocator
import numpy as np

params = {"backend": "ps", "text.usetex": True, "font.family": "serif"}
#matplotlib.rcParams.update(params)

PARENT_OUTPUT_DIR = "../03_output/"


METRICS = [
    # filename, y-Label, smooth boolean
    ("milli_cpu", "Ratios", False),
]

PLOTS = {
    "plot-1": (  # plotName
        ["no-scale"],  # scenarios
        {"registration": 1800, "deregistration": 250},  # times
        METRICS,
    ),
    # "plot-2": (  # plotName
    #     ["hpa-fast-500m-100"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-3": (  # plotName
    #     ["hpa-fast-500m-90"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-4": (  # plotName
    #     ["hpa-fast-500m-80"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    "plot-5": (  # plotName
        ["hpa-fast-500m-80-2"],  # scenario
        {"registration": 1800, "deregistration": 250},  # times
        METRICS,
    ),
    # "plot-6": (  # plotName
    #     ["hpa-def-500m-80"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-7": (  # plotName
    #     ["hpa-15s-500m-80"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-8": (  # plotName
    #     ["hpa-15s-500m-80-2"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
    # "plot-9": (  # plotName
    #     ["hpa-15s-500m-80-3"],  # scenario
    #     {"registration": 1800, "deregistration": 250},  # times
    #     METRICS,
    # ),
}
PROCEDURES = ["reg"]
# FUNCTIONS = ["amf-stateless", "gnb", "mongod", "nrf", "udm-stateless", "udr-stateless"]
FUNCTIONS = ["amf-stateless", "udm-stateless", ]
# FUNCTIONS = ["amf-stateless", "nrf", ]
RATIOS = ["nrf/amf", "udm/amf", "udr/amf"]
INPUT_DIR = "../01_measurements/unzipped"
ROLLING_AVERAGE = 10

RATIOS_VALUES = {"nrf": 0.75,
                 "udm": 0.65,
                 "udr": 0.60
                 }



for plot in PLOTS.items():
    plotName, value = plot
    scenarios, times, theseMetrics = value
    for procedure in PROCEDURES:
        fig, axes = plt.subplots(
            nrows=1,
            ncols=1,
            figsize=(9, 3 + 2*len(theseMetrics)),
            sharex=True,
        )
        axes = list(axes) if len(theseMetrics) > 1 else [axes]
        ax = axes.pop()
        styles = [
            (["#E09516", "#E09516", "#E09516"], ["-", "--"]),
            (["#8916E0", "#8916E0", "#8916E0"], ["-", "--"]),
            (["#00E059", "#00E059", "#00E059"], ["-", "--"]),
            (["#4885E0", "#4885E0", "#4885E0"], ["-", "--"]),
            (["#eb2828", "#eb2828", "#eb2828"], ["-", "--"]),
            (["#000000", "#000000", "#000000"], ["-", "--"]),
        ]
        zorder_array = [0, 10, 0]
        alpha = [1, 0.2]

        # This code is executed only when we want to plot the ratios in addition to the instances and cpu.
        for function in FUNCTIONS:
            if function != "gnb" and function != "mongod":
                df = DataFrame()
                print(plotName + "#" + function)
                color, style = styles.pop()
                index = 0
                for scenario in scenarios:
                    df = DataFrame()

                    file = (
                        f"{INPUT_DIR}/{scenario}/{procedure}_milli_cpu.csv"
                    )
                    m = read_csv(file)

                    # df.rename(columns={"amf-stateless": "amf"}, inplace=True)
                    # df.rename(columns={"udm-stateless": "udm"}, inplace=True)
                    # df.rename(columns={"udr-stateless": "udr"}, inplace=True)

                    print(file)
                    print(m.tail(1))

                    df[f"{function}"] = m[function]

                    if function == "amf-stateless":
                        # df["expected-nrf"] = df["amf-stateless"] * 0.75
                        df["expected-udm"] = df["amf-stateless"] * 0.65
                        # df["expected-udr"] = df["amf-stateless"] * 0.60

                    df.plot(
                        ylabel="Expected CPU Utilization",
                        xlabel="Seconds",
                        ax=ax,
                        sharex=True,
                        x_compat=True,
                        style=style[index],
                        # color={'amf-stateless': "#00E059", 'nrf': '#8916E0', 'expected-nrf': '#E09516'},
                        color={'amf-stateless': "#00E059", 'udm-stateless': '#8916E0', 'expected-udm': '#E09516'},
                        # color={'amf-stateless': "#00E059", 'nrf': '#8916E0', 'expected-nrf': '#E09516'},
                        legend=False,
                        zorder=zorder_array[index],
                        alpha=alpha[index]
                    )
                    index += 1

                ax.yaxis.set_major_locator(MaxNLocator(integer=True))
                print(len(df))
                ax.xaxis.set_ticks(np.arange(0, len(df), 50))
                ax.xaxis.grid(True, alpha=0.5)
                ax.yaxis.grid(True, alpha=0.5)

                ax.legend(
                    loc="lower center",
                    ncol=len(FUNCTIONS)+1,
                    bbox_to_anchor=(0.5, 1.0)
                )

                ax.minorticks_off()

        # plt.tight_layout()
        plt.minorticks_off()
        fig.suptitle(f"{scenarios[0]}")


        # output_dir = PARENT_OUTPUT_DIR + f"{scenario}/"
        # try:
        #     # Create target Directory
        #     os.mkdir(output_dir)
        #     print("Directory \"", output_dir, "\" created.")
        # except FileExistsError:
        #     print("Directory \"", output_dir, "\" already exists.")
        #
        # if len(theseMetrics) == 2: #  meaning there are two metrics
        #     plt.savefig(output_dir + f"{theseMetrics[0][0]}_{theseMetrics[1][0]}_{procedure}.png")
        # elif len(theseMetrics) == 3:
        #     plt.savefig(output_dir + f"all_metrics_{procedure}.png")
        plt.show()
